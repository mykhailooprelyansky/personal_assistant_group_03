# Comand Line Interface assistant

## What is this?

The CLI assistant allows you to:
Create and work with Contacts lists.
Create and work with the notes.
Sorting files in the folders.
You can choose your options in the console.

## Install Guide

To install this package open the terminal in your code editor and type:

pip install personal-cli-assistant

### Using

Using the CLI assistant provides by next steps:

1. Open the terminal in your code editor
2. Type: start_cli
3. Command Line interface give you all hints to make different actions.

---

## Developer

Our url: [link](https://github.com/mykhailooprelyansky/personal_assistant_group_03)
